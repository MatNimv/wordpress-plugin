<?php
// Abort if called directly (ie. not from WordPress)
if (!defined("WP_UNINSTALL_PLUGIN")) {
    exit();
}

