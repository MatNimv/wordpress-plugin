<?php

/**
 * Plugin Name: Matildas Plugin
 * Description: Mitt första plugin!! WOOOO
 * Version: 0.0.4
 * Author: Matnimv
 */

 // Include admin stuff (menu item, settings page)
 require_once __DIR__ . "/admin/matildas-plugin-admin.php";
 // Include public stuff (shortcode)
 require_once __DIR__ . "/public/matildas-plugin-public.php";